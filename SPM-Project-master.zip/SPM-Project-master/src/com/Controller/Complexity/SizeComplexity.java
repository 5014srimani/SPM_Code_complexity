package com.Controller.Complexity;

import com.Interface.AbstractComplexityFinder;
import com.Model.Complexity;

public class SizeComplexity extends AbstractComplexityFinder {

	public SizeComplexity(String line) {
		super(line);
	}

	@Override
	public Complexity GetComplexity() {
		// TODO Auto-generated method stub
		return null;
	}
}
