package com.Interface;

import com.Model.Complexity;

public interface ComplexityFinder {
	public Complexity GetComplexity();
}
